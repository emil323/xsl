<?php
/**
 * Created by PhpStorm.
 * User: Kristoffer
 * Date: 19.10.2018
 * Time: 16:44
 */

?>

</div> <!-- End of content -->
</div> <!-- End of container -->
</body>
<script type="text/javascript" src="./app.js"></script>
</html>
