<?php
/**
 * Created by PhpStorm.
 * User: Kristoffer
 * Date: 19.10.2018
 * Time: 16:44
 */
?>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="./stylesheet.css"/>
</head>
<body>

<nav>
    <ul id="navList">
        <li class="navListItem"><a class="active" href="index.php">Hjem</a></li>
        <li class="navListItem"><a href="about.php">About</a></li>
    </ul>
</nav>
<div class="container">
        <div class="content">
<header>
</header>

