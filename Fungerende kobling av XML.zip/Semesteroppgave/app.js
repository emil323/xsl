// Definerer noen UI variabler
const filter = document.querySelector('#filter');

filter.addEventListener('keyup', filterRoads);

function filterRoads(e) {
    const text = e.target.value.toLowerCase(); // Gir hva som blir skrevet inn

    document.querySelectorAll('.road-heading-list-elements').forEach(function (road) {
        const item = road.firstChild.textContent;

        if(item.toLowerCase().indexOf(text) != -1) {
            road.style.display = 'block';
        } else {
            road.style.display = 'none';
        }
    });
}